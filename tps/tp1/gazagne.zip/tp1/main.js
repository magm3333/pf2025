import { setPagina, setCantidad, setFile, fetchData } from './modulos/fetchDB.js';

function parsearArgumentos() {
    const args = process.argv.slice(2);
    let cantidad = 3;
    let file = './db.json';

    for (let i = 0; i < args.length; i++) {
        if (args[i] === '-c' || args[i] === '--cantidad') {
            cantidad = parseInt(args[i + 1]) || 3;
            i++;
        } else if (args[i] === '-f' || args[i] === '--file') {
            file = args[i + 1] || './db.json';
            i++;
        }
    }

    return { cantidad, file };
}

async function main() {
    try {
        const { cantidad, file } = parsearArgumentos();

        console.log(`Configurando módulo...`);
        console.log(`- Cantidad: ${cantidad}`);
        console.log(`- Archivo: ${file}`);

        // Configurar el módulo
        setPagina(1);
        setCantidad(cantidad);
        setFile(file);

        console.log(`\nObteniendo ${cantidad} usuarios...`);
        
        const resultado = await fetchData();
        
        console.log("\nOperación completada:");
        console.log(`- Usuarios agregados: ${resultado.usuariosAgregados}`);
        console.log(`- Total en archivo: ${resultado.totalUsuarios}`);
        console.log("---------------------------------------------------------------");

    } catch (error) {
        console.error('Error en el programa:', error.message);
        process.exit(1);
    }
}

main();