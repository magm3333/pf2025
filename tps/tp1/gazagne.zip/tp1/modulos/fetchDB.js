import fetch from 'node-fetch';
import fs from 'fs/promises';
import path from 'path';

let estado = {
    pagina: 1,
    cantidad: 3,
    file: './db.json'
};

export const setPagina = (num) => {
    estado.pagina = num;
};

export const setCantidad = (cant) => {
    estado.cantidad = cant;
};

export const setFile = (pathToFile) => {
    estado.file = pathToFile;
};

// Función para asegurar que el directorio existe
const asegurarDirectorio = async (filePath) => {
    const dir = path.dirname(filePath);
    try {
        await fs.access(dir);
    } catch (error) {
        if (error.code === 'ENOENT') {
            // El directorio no existe, crearlo
            await fs.mkdir(dir, { recursive: true });
            console.log(`Directorio creado: ${dir}`);
        } else {
            throw error;
        }
    }
};

export const fetchData = async () => {
    try {
        const { pagina, cantidad, file } = estado;

        // Asegurar que el directorio existe
        await asegurarDirectorio(file);

        // 1) Crear o leer el archivo
        let existingData = [];
        
        try {
            const fileContent = await fs.readFile(file, 'utf-8');
            existingData = JSON.parse(fileContent);
            console.log(`Archivo ${file} leído exitosamente`);
        } catch (error) {
            if (error.code === 'ENOENT') {
                // Archivo no existe, crear con array vacío
                await fs.writeFile(file, JSON.stringify([], null, 2));
                console.log(`Archivo ${file} creado exitosamente`);
            } else {
                throw error;
            }
        }

        // 2) Hacer fetch a la API
        console.log(`Solicitando ${cantidad} usuarios para página ${pagina}...`);
        const respuestaHttp = await fetch(
            `https://randomuser.me/api/?page=${pagina}&results=${cantidad}`
        );
        
        if (!respuestaHttp.ok) {
            throw new Error(`Error HTTP: ${respuestaHttp.status}`);
        }
        
        const datosJson = await respuestaHttp.json();
        const nuevosUsuarios = datosJson.results || [];

        // 3) Agregar y actualizar archivo
        const dataActualizada = [...existingData, ...nuevosUsuarios];
        await fs.writeFile(file, JSON.stringify(dataActualizada, null, 2));

        console.log(`Datos actualizados en ${file}`);

        return {
            usuariosAgregados: nuevosUsuarios.length,
            totalUsuarios: dataActualizada.length,
            data: nuevosUsuarios
        };

    } catch (error) {
        console.error('Error en fetchData:', error.message);
        throw error;
    }
};

export const resetEstado = () => {
    estado = {
        pagina: 1,
        cantidad: 3,
        file: './db.json'
    };
};