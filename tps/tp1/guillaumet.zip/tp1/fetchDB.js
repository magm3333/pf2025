// Importa el módulo de promesas de fs para manejo de archivos asíncrono
const fs = require("fs").promises;

// Variables globales para la cantidad de usuarios, el path del archivo y el contenido del archivo
let cantidad = 1;
let path = "./db.json";
let file = [];

// Establece la cantidad de usuarios a pedir a la API
let setPagina = (num) => {
  cantidad = num;
};

// Establece el archivo a usar. Si no existe, lo crea vacío ([])
let setFile = async (pathToFile) => {
  path = pathToFile;
  try {
    // Intenta leer el archivo y parsear su contenido
    const data = await fs.readFile(pathToFile, "utf-8");
    file = JSON.parse(data);
  } catch (err) {
    // Si el archivo no existe, lo crea vacío
    file = [];
    await fs.writeFile(pathToFile, JSON.stringify([]));
  }
};

// Hace un fetch a la API randomuser.me y guarda los resultados en el archivo
let fetch = async (cantidad = cantidad) => {
  // Construye la URL con la cantidad de usuarios
  let url = `https://randomuser.me/api/?results=${cantidad}`;

  // Realiza la petición HTTP
  const response = await globalThis.fetch(url);
  const data = await response.json();

  // Agrega los resultados al archivo
  await writeFile(data.results);
};

// Escribe (append) los nuevos datos al archivo JSON
let writeFile = async (data) => {
  file = file.concat(data);
  await fs.writeFile(path, JSON.stringify(file, null, 2));
};

// Exporta las funciones del módulo
module.exports = { setPagina, setFile, fetch };
