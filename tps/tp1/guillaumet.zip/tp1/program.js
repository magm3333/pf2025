// Importa el módulo fetchDB
const fetchDB = require("./fetchDB");

// Valores por defecto para cantidad y archivo
let cantidad = 3;
let pathToFile = "./db.json";

// Procesa los argumentos de línea de comandos para cantidad y archivo
process.argv.forEach((arg) => {
  if (arg.startsWith("-c")) {
    cantidad = parseInt(arg.split("=")[1]);
  }
  if (arg.startsWith("-f")) {
    pathToFile = arg.split("=")[1];
  }
});

// Función principal asíncrona
async function main() {
  // Inicializa el archivo (lo crea si no existe)
  await fetchDB.setFile(pathToFile);
  // Establece la cantidad de usuarios a pedir
  fetchDB.setPagina(cantidad);
  // Hace el fetch y guarda los datos
  await fetchDB.fetch();
}

// Ejecuta la función principal y muestra errores si ocurren
main().catch(console.error);
